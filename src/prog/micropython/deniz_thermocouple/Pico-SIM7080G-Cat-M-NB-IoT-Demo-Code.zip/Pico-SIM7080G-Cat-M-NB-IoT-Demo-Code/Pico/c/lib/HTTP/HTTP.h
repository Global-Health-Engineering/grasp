#ifndef _HTTP_H_
#define _HTTP_H_

#include "DEV_Config.h"

void http_post();
void http_get();



#endif
