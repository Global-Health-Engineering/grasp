#include "Pico_SIM7080G_NB_loT.h"
void main()
{
    /*******AT**********/
    // Pico_SIM7080G_NB_loT_AT(); 
    /*******HTTP**********/
    // Pico_SIM7080G_NB_loT_HTTP();
    /*******MQTT**********/
    // Pico_SIM7080G_NB_loT_MQTT();
    /*******GPS**********/
    Pico_SIM7080G_NB_loT_GPS();
}